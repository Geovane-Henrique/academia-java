package controler;
import produto.Armazem;
import produto.Produtonp;
import produto.Produtop;
import repositroioBD.CadastroProdutonp;
import repositroioBD.CadastroProdutop;

import java.util.ArrayList;
import java.util.Scanner;

public class Cadastros {
	/* static ArrayList<Produtop> alimento = new ArrayList<>();
	 public static ArrayList<Produtonp> objeto = new ArrayList<>();*/
	 Produtop produtop = new Produtop();
	 Produtonp produtonp = new Produtonp();
	 
	Scanner input = new Scanner(System.in);	 
public void cadastros() {
	
	}
		
	public void cadastroproduto(){		
		String c;
		do {		
			System.out.println("Suplemento(Sim/Nao)?");
			String op = input.nextLine();
			
			if(op.equalsIgnoreCase("Sim")) {
			 System.out.println("Nome: ");
			 String nome = input.nextLine();
			    
			    
			    System.out.println("Valor: ");
			  double  valor = input.nextDouble();
			  		 
               System.out.println("Quantidade: ");
                int qtd = input.nextInt();
                
                System.out.println("Peso(kg): ");
  			  int  peso= (int) input.nextDouble();
			  
			  int id = produtop.getId();
			   id++;		    			  
			    Produtop p1 = new Produtop(nome,valor,qtd,peso,id);
			    try {
					CadastroProdutop.inserir(p1);
				} catch (Exception e) {
					System.out.println("ERRO AO CONECTAR COM O BANCO DE DADOS");
					e.printStackTrace();
				}
			    }
			   // alimento.add(p1);}
			else {		
				 System.out.println("Nome: ");
				 String nome = input.nextLine();
				 
				    System.out.println("Valor: ");
				  double  valor = input.nextDouble();
				  		 
	               System.out.println("Quantidade: ");
	                int qtd = input.nextInt();
	                
	                          
	                System.out.println("Descrição: ");
	  			  String desc =  input.next();
	  			  
	  			int id = produtop.getId();
                id++;
				 
				Produtonp p = new Produtonp(nome,valor,qtd,desc,id);
				//objeto.add(p);
				try {
					CadastroProdutonp.inserir(p);
				} catch (Exception e) {
					System.out.println("ERRO AO CONECTAR COM O BANCO DE DADOS");
					e.printStackTrace();
				}
			}
			    
			System.out.println("");
		    c = input.nextLine();
	}while(c.equalsIgnoreCase("Sim"));
		}
	}
			
		
		
		
		
	
	/*public static ArrayList<Produtop> getprodutop(){
        return alimento;
    }
	public static ArrayList<Produtonp> getprodutonp(){
        return objeto;
    }
}
		*/			
				
			

			
	
	
	



