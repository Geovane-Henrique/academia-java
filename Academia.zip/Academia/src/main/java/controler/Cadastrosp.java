package controler;

import pessoa.Cliente;
import pessoa.Funcionario;
import repositroioBD.CadastroCliente;
import repositroioBD.CadastroFuncionario;

import java.util.ArrayList;
import java.util.Scanner;


public class Cadastrosp {
	private static final ArrayList<Cliente> clientes = new ArrayList<>();
	private static final ArrayList<Funcionario> funcionarios = new ArrayList<>();
	Cliente cliente;
	Funcionario funcionario;
	public static void cadastrarCliente() {
        System.out.print("Nome: ");
        Scanner input = new Scanner(System.in);

        String nome = input.nextLine();
        if (nome.length() < 3 || nome.length() > 30) {
            System.out.println("Nome inválido. Deve ter entre 3 e 30 caracteres.");
        }

        System.out.print("CPF: ");
        String cpf = input.nextLine();
        if (cpf.length() != 11) {
            System.out.println("CPF inválido. Deve conter 11 dígitos.");
        }

        System.out.print("Telefone: 9 ");
        String fone = input.nextLine();
        if (fone.length() != 8) {
            System.out.println("Número de telefone inválido. Deve ter 8 dígitos.");
        }

        System.out.print("Idade: ");
        int idade = input.nextInt();
        if (idade <= 14 || idade >= 100) {
            System.out.println("Idade inválida. Deve ser maior que 13 e menor que 100.");
        }

        System.out.print("Sexo (M/F): ");
        char sexo = input.next().charAt(0);
        if (Character.toUpperCase(sexo) != 'M' && Character.toUpperCase(sexo) != 'F') {
            System.out.println("Sexo inválido. Deve ser 'M' ou 'F'.");
        }

        System.out.println("Escolha o tipo de plano (Mensal/Anual):");
        String plano = input.next();
        if (!plano.equalsIgnoreCase("Mensal") && !plano.equalsIgnoreCase("Anual")) {
            System.out.println("Tipo de plano inválido. Deve ser 'Mensal' ou 'Anual'.");
        }
        Cliente cliente = new Cliente(nome, cpf, fone, idade, sexo, plano);
        clientes.add(cliente);
        try {
			CadastroCliente.inserir(cliente);
		} catch (Exception e) {
			System.out.println("ERRO AO CONECTAR COM O BANCO DE DADOS");
			e.printStackTrace();
		}
        System.out.println("\nAluno cadastrado com sucesso!");
    }
	
	

    public static void cadastrarFuncionario(){
        Scanner input = new Scanner(System.in);
        System.out.print("Nome: ");

        String nome = input.nextLine();
        if (nome.length() < 3 || nome.length() > 30) {
            System.out.println("Nome inválido. Deve ter entre 3 e 30 caracteres.");
            return;
        }

        System.out.print("CPF: ");
        String cpf = input.nextLine();
        if (cpf.length() != 11) {
            System.out.println("CPF inválido. Deve conter 11 dígitos.");
            return;
        }

        System.out.print("Telefone: 9 ");
        String fone = input.nextLine();
        if (fone.length() != 8) {
            System.out.println("Número de telefone inválido. Deve ter 8 dígitos.");
            return;
        }

        System.out.print("Idade: ");
        int idade = input.nextInt();
        if (idade < 20 || idade >= 100) {
            System.out.println("Idade inválida. Deve ser no mínimo 21 e menor que 100.");
            return;
        }

        System.out.print("Sexo (M/F): ");
        char sexo = input.next().charAt(0);
        if (Character.toUpperCase(sexo) != 'M' && Character.toUpperCase(sexo) != 'F') {
            System.out.println("Sexo inválido. Deve ser 'M' ou 'F'.");
            return;
        }

        System.out.println("Cargo (Instrutor/Recepcionista):");
        String cargo = input.next();
        if (!cargo.equalsIgnoreCase("Instrutor") && !cargo.equalsIgnoreCase("Recepcionista")) {
            System.out.println("Cargo inválido. Deve ser 'Instrutor' ou 'Recepcionista'.");
            return;
        }
        
        Funcionario funcionario = new Funcionario(nome,cpf,   fone, idade, sexo, cargo);
        funcionarios.add(funcionario);
        try {
			CadastroFuncionario.inserir(funcionario);
		} catch (Exception e) {
			System.out.println("ERRO AO CONECTAR COM O BANCO DE DADOS");
			e.printStackTrace();
		}
       
        System.out.println("\nFuncionário cadastrado com sucesso!");
    }
   
}
