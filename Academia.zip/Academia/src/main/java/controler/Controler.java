package controler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.mysql.cj.jdbc.result.ResultSetMetaData;


import conexao.Conexao;
import menu.Menu;
import opcao.Variaveis;
import produto.Produtonp;
import produto.Produtop;

public class Controler {
	static Scanner input = new Scanner(System.in);
	static Variaveis Variaveis;
	static Menu Menu;
	Conexao conexao;
	
	public static void exibirr() throws Exception {
		Connection conn = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            conn = Conexao.getConexao(); 

            statement = conn.createStatement();

            String consultaSQL = "SELECT * FROM produtonp";
            resultSet = statement.executeQuery(consultaSQL);

            ResultSetMetaData metaData = (ResultSetMetaData) resultSet.getMetaData();
            int numColunas = metaData.getColumnCount();

            while (resultSet.next()) {
                for (int i = 1; i <= numColunas; i++) {
                    System.out.print(metaData.getColumnLabel(i) + ": " + resultSet.getString(i) + " ");
                }
                System.out.println();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
          }
        }
	
	
	
	public static void listarAlunos() throws Exception {
		Connection conn = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            conn = Conexao.getConexao(); 

            statement = conn.createStatement();

            String consultaSQL = "SELECT * FROM cliente";
            resultSet = statement.executeQuery(consultaSQL);
          
            ResultSetMetaData metaData = (ResultSetMetaData) resultSet.getMetaData();
            int numColunas = metaData.getColumnCount();

            while (resultSet.next()) {
                for (int i = 1; i <= numColunas; i++) {
                    System.out.print(metaData.getColumnLabel(i) + ": " + resultSet.getString(i) + " ");
                }
                System.out.println();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {           
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
       }
	
	
	public static void listarFuncionarios () throws Exception {
		Connection conn = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            conn = Conexao.getConexao(); 

            statement = conn.createStatement();

            String consultaSQL = "SELECT * FROM funcionario";
            resultSet = statement.executeQuery(consultaSQL);
            
            ResultSetMetaData metaData = (ResultSetMetaData) resultSet.getMetaData();
            int numColunas = metaData.getColumnCount();

            while (resultSet.next()) {
                for (int i = 1; i <= numColunas; i++) {
                    System.out.print(metaData.getColumnLabel(i) + ": " + resultSet.getString(i) + " ");
                }
                System.out.println();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
       }
	
	public static void exibir() throws Exception {
		Connection conn = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            conn = Conexao.getConexao(); 
          
            statement = conn.createStatement();
           
            String consultaSQL = "SELECT * FROM produtop";
            resultSet = statement.executeQuery(consultaSQL);
           
            ResultSetMetaData metaData = (ResultSetMetaData) resultSet.getMetaData();
            int numColunas = metaData.getColumnCount();

            while (resultSet.next()) {
                for (int i = 1; i <= numColunas; i++) {
                    System.out.print(metaData.getColumnLabel(i) + ": " + resultSet.getString(i) + " ");
                }
                System.out.println();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {           
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        }
    

	
	public static void adicionarUnidade() throws Exception {
        Connection conn = null;
        PreparedStatement preparedStatement = null;

        try {
           
        	exibir();
        	
            conn = Conexao.getConexao();

          
            String sql = "UPDATE produtop SET quantidade = quantidade + ? WHERE id = ?";
           
            System.out.println("\nDigite o ID do produto a acrescentar unidades: ");
            int produtoId = input.nextInt();
            System.out.println("Unidades a adicionar: ");
            int valorAdicional = input.nextInt();

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, valorAdicional);
            preparedStatement.setInt(2, produtoId);

            int linhasAfetadas = preparedStatement.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("\nProduto atualizado no estoque!");
            } else {
                System.out.println("\nProduto não encontrado. Verifique o ID do produto.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
	
	public static void adicionarUnidadee() throws Exception {
        Connection conn = null;
        PreparedStatement preparedStatement = null;

        try {
           
        	exibirr();
        	
            conn = Conexao.getConexao();

          
            String sql = "UPDATE produtonp SET quantidade = quantidade + ? WHERE id = ?";
           
            System.out.println("\nDigite o ID do produto a acrescentar unidades: ");
            int produtoId = input.nextInt();
            System.out.println("Unidades a adicionar: ");
            int valorAdicional = input.nextInt();

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, valorAdicional);
            preparedStatement.setInt(2, produtoId);

            int linhasAfetadas = preparedStatement.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("\nProduto atualizado no estoque!");
            } else {
                System.out.println("\nProduto não encontrado. Verifique o ID do produto.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
	
	public static void removerUnidade() throws Exception {
        Connection conn = null;
        PreparedStatement preparedStatement = null;

        try {
           
             exibir();
        
            conn = Conexao.getConexao();

            
            String sql = "UPDATE produtos SET quantidade = GREATEST(quantidade - ?, 0) WHERE id = ?";

            
            System.out.println("Digite o ID do produto a retirar unidades: ");
            int produtoId = input.nextInt();
            System.out.println("Unidades a retirar: ");
            int valorRetirar = input.nextInt();

           
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, valorRetirar);
            preparedStatement.setInt(2, produtoId);
           
            int linhasAfetadas = preparedStatement.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("\nProduto atualizado no estoque!");
            } else {
                System.out.println("\nProduto não encontrado ou quantidade insuficiente. Verifique o ID do produto.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
	
	public static void removerUnidadee() throws Exception {
        Connection conn = null;
        PreparedStatement preparedStatement = null;

        try {
           
             exibirr();
        
            conn = Conexao.getConexao();

            
            String sql = "UPDATE produtos SET quantidade = GREATEST(quantidade - ?, 0) WHERE id = ?";

            
            System.out.println("Digite o ID do produto a retirar unidades: ");
            int produtoId = input.nextInt();
            System.out.println("Unidades a retirar: ");
            int valorRetirar = input.nextInt();

           
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, valorRetirar);
            preparedStatement.setInt(2, produtoId);
           
            int linhasAfetadas = preparedStatement.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("\nProduto atualizado no estoque!");
            } else {
                System.out.println("\nProduto não encontrado ou quantidade insuficiente. Verifique o ID do produto.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
	
	
	
public static void pagarprodutoo() throws Exception{
		
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            

            conn = Conexao.getConexao();
           
            String sql = "SELECT id, Nome, valor FROM produtonp WHERE id = ?";
          
            System.out.println("\nDigite o ID do produto a ser comprado: ");
            int produtoId = input.nextInt();

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, produtoId);

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                String nome = resultSet.getString("nome");
                double valor = resultSet.getDouble("valor");

                System.out.println("\nID: " + id + "\nNome: " + nome + "\nValor: " + valor);
                
                System.out.println("\n1. Confirmar compra ");
                System.out.println("2. Cancelar compra ");
                int op = input.nextInt();

                if(op == 1)
                	System.out.println("\nCompra feita com sucesso! ");
                
            } else {
                System.out.println("\nProduto não encontrado. Verifique o ID do produto.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
	

public static void pagarproduto() throws Exception{
	
	Connection conn = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    try {
        

        conn = Conexao.getConexao();
       
        String sql = "SELECT id, Nome, valor FROM produtop WHERE id = ?";
      
        System.out.println("\nDigite o ID do produto a ser comprado: ");
        int produtoId = input.nextInt();

        preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setInt(1, produtoId);

        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            int id = resultSet.getInt("id");
            String nome = resultSet.getString("nome");
            double valor = resultSet.getDouble("valor");

            System.out.println("\nID: " + id + "\nNome: " + nome + "\nValor: " + valor);
            
            System.out.println("\n1. Confirmar compra ");
            System.out.println("2. Cancelar compra ");
            int op = input.nextInt();

            if(op == 1)
            	System.out.println("\nCompra feita com sucesso! ");
            
        } else {
            System.out.println("\nProduto não encontrado. Verifique o ID do produto.");
        }

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        
        try {
            if (resultSet != null) resultSet.close();
            if (preparedStatement != null) preparedStatement.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
	
}


