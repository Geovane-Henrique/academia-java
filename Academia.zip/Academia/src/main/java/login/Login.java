package login;

import java.util.Scanner;
import menu.Menu;
import opcao.Variaveis;

public class Login {
	
	static Menu menu = new Menu();
	static Variaveis opcao = new Variaveis();
	
	
	public static void clientesenha() throws Exception{
		Scanner input = new Scanner(System.in);
		
		System.out.println("\nDigite sua senha: ");
		int senha;
		senha = input.nextInt();
		
		if(senha == 1) {
			
			menu.menucliente();
			opcao.vcliente();
						
		}
	}
		public static void funcionariosenha() throws Exception{
			Scanner input = new Scanner(System.in);
			
			System.out.println("\nDigite sua senha:");
			int senha;
			senha = input.nextInt();
			
			if(senha == 1) {
				
				menu.menuadmin();
				opcao. vadmin();
							
			}
		
	}

}
