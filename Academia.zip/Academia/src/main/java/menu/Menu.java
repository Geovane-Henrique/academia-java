package menu;

public class Menu{
	
	public void Menulogin() {
		
	  System.out.println("\n==== MENU ====");
	  System.out.println("1. Cliente");
	  System.out.println("2. Funcionário");
	  System.out.println("3. Sair");
	  System.out.print("\nDigite uma opção: ");
	  
          }
public static void menucliente(){
	System.out.println("\n==== MENU ====");
	System.out.println("1. Comprar produto");
	System.out.println("2. Consultar Planos");
	System.out.println("3. Voltar");
	System.out.println("\nDigite uma opção: ");

	}

	public void menufuncionarios(){
		
		System.out.println("\n==== MENU ====");
		System.out.println("1. Administrador");
		System.out.println("2. Voltar");
		
}
	 public void menuadmin() {
		 
		 System.out.println("\n==== MENU ====");
		 System.out.println("1. Gerenciar Produtos");
		 System.out.println("2. Gerenciar Clientes");
		 System.out.println("3. Gerenciar Funcionários");
		 System.out.println("4. Voltar");
		 System.out.println("\nDigite uma opção: ");
	 }

	 public void adminproduto() {
		System.out.println("\n==== MENU ====");
		System.out.println("1. Cadastrar produtos");
		System.out.println("2. Adicionar ao estoque");
		System.out.println("3. Retirar do estoque");
		System.out.println("4. Conferir estoque");
		System.out.println("5. Voltar");
		
	}
	public void estiloproduto() {
		System.out.println("\n==== MENU ====");
		System.out.println("1. Proteínas");
		System.out.println("2. Objetos");
		System.out.println("3. Voltar");
		
	}
	public void admincliente() {
		System.out.println("\n==== MENU ====");
		System.out.println("1. Cadastrar cliente");
		System.out.println("2. Exibir clientes");
		System.out.println("3. Voltar");
		
	}
	public void adminfuncionario() {
		System.out.println("\n==== MENU ====");
		System.out.println("1. Cadastrar funcionário");
		System.out.println("2. Exibir funcionários");
		System.out.println("3. Voltar");
		
	}
	public void planos() {
		System.out.println("\n==== MENU ====");
		System.out.println("Mensal   R$ 80.00");
		System.out.println("Anual   R$ 840.00 (12,5% de desconto!!)");
	
		
	}
}
	
	  
	
	
	
	 
	
	

