package opcao;
import java.util.Scanner;

import controler.Cadastrosp;
import controler.Controler;
import menu.Menu;
import controler.Cadastros;
import produto.Carrinho;
import produto.Produtonp;
import produto.Produtop;


public class Variaveis {
	static Cadastros cadastros = new Cadastros();
	static Menu Menu = new Menu();
	Carrinho produtoo = new Carrinho();
	Produtop produtop;
	Produtonp produtonp;
	static Cadastrosp cadastrosp = new Cadastrosp();
	static Controler Controler;
	
	public Variaveis(Produtonp produtonp)  {
        this.produtonp = produtonp;
   }
	
	public Variaveis(Produtop produtop) {
        this.produtop = produtop;
   }
	
	 public Variaveis() {
		 
	 }
		
    public static void vcliente() throws Exception {
    	 Scanner input = new Scanner(System.in);
        int op;

        op = input.nextInt();
        switch (op) {
            case 1:Menu.estiloproduto();
            estiloproduto();
                          
                break;
            case 2:Menu.planos();
                break;                 
            default:
                
                break;
        }
    }

    public void vproduto() {
        Scanner input = new Scanner(System.in);
        int op;
        op = input.nextInt();

        switch (op) {
            case 1:
                
                break;
            case 2:
                break;
            default:
                System.out.println("Opção inválida!");
                break;
        }
    }

    public static void vadmin() throws Exception {
        Scanner input = new Scanner(System.in);
        int op;
        op = input.nextInt();

        switch (op) {
            case 1:
                Menu.adminproduto();
                adminproduto();
                break;
            case 2:Menu.admincliente();
            admincliente();
                break;
            case 3:Menu.adminfuncionario();
            adminfuncionario();          
                break;
            default:
                
                break;
        }
    }

    public static void adminproduto() throws Exception {
        Scanner input = new Scanner(System.in);
        int op;
        op = input.nextInt();

        switch (op) {
        
            case 1:
                cadastros.cadastroproduto(); 
                System.out.println("\nProduto cadastrado com sucesso!");
                Menu.adminproduto();
                adminproduto();
               vadmin();
                break;
            case 2:
            	
            	Menu.estiloproduto();
            	adicionarproduto();
            	
                break;
            case 3:
            	Menu.estiloproduto();
            	removerproduto();
            	break;
            case 4:Controler.exibir();
            	Controler.exibirr();
            
            Menu.adminproduto();
     	     adminproduto();
            break;
            case 5:
            	Menu.menuadmin();
            	vadmin();
            default:
                System.out.println("");
                break;
        }
    }

    public void escolherproduto() {
        Scanner input = new Scanner(System.in);
        
        int op;

        op = input.nextInt();
        switch (op) {
            case 1:
                Menu.adminproduto();
                break;
            case 2:
                break;
            default:
                System.out.println("Opção inválida!");
                break;
        }
    }
    
    public static void estiloproduto() throws Exception {
    Scanner input = new Scanner(System.in);
    
    int op;

    op = input.nextInt();
    switch (op) {
        case 1:Controler.exibir();
        Controler.pagarproduto();
        
        Menu.menucliente();
        vcliente();
               
            break;
        case 2:Controler.exibirr();
        Controler.pagarprodutoo();
        
        Menu.menucliente();
        vcliente();
       
            break;
        case 3:Menu.adminproduto();
  	     adminproduto();
        default:
            System.out.println("Opção inválida!");
            break;
            }
    }
    public static void adicionarproduto() throws Exception {
    	 Scanner input = new Scanner(System.in);
    	    
    	    int op;

    	    op = input.nextInt();
    	    switch (op) {
    	        case 1:Controler.adicionarUnidade(); 
    	        
    	        Menu.adminproduto();
    	  	     adminproduto();
    	            
    	            break;
    	        case 2:Controler.adicionarUnidadee();
    	        
    	        Menu.adminproduto();
    	  	     adminproduto();
    	        	
    	            break;
    	        case 3:
    	        	Menu.adminproduto();
    	      	     adminproduto();
    	        default:
    	            System.out.println("Opção inválida!");
    	            break;
    	            }
    }
    public static void removerproduto() throws Exception {
   	 Scanner input = new Scanner(System.in);
   	    
   	    int op;

   	    op = input.nextInt();
   	    switch (op) {
   	        case 1:Controler.removerUnidade();
   	        
   	     Menu.adminproduto();
  	     adminproduto();
   	            
   	            break;
   	        case 2:Controler.removerUnidadee();
   	        
   	     Menu.adminproduto();
  	     adminproduto();
   	        	
   	            break;
   	        case 3:Menu.adminproduto();
   	     adminproduto();
   	        default:
   	            System.out.println("Opção inválida!");
   	            break;
   	            }
   }
    public static void admincliente() throws Exception {
Scanner input = new Scanner(System.in);
   	    
   	    int op;

   	    op = input.nextInt();
   	    switch (op) {
   	        case 1:cadastrosp.cadastrarCliente();
   	            Menu.admincliente();
   	         admincliente();
   	            break;
   	        case 2:Controler.listarAlunos();
   	     Menu.admincliente();
	         admincliente();
   	            break;
   	        case 3:Menu.menuadmin();
   	              vadmin();   	            
   	            break;
   	     default:
	            System.out.println("Opção inválida!");
	            break;    
   	            }
    	
    }
    
    
    public static void adminfuncionario() throws Exception {
    	Scanner input = new Scanner(System.in);
    	   	    
    	   	    int op;

    	   	    op = input.nextInt();
    	   	    switch (op) {
    	   	        case 1:cadastrosp.cadastrarFuncionario();
    	   	     Menu.adminfuncionario();
    	   	     adminfuncionario();
    	   	            break;
    	   	        case 2:Controler.listarFuncionarios();
    	   	        Menu.adminfuncionario();
    	   	     adminfuncionario();
    	   	        	
    	   	            break;
    	   	        case 3:Menu.menuadmin();
     	              vadmin();
     	              
     	              break;
    	   	        default:
    	   	            System.out.println("Opção inválida!");
    	   	            break;
    	   	            }
    	    	
    	    }
    	    
}








		
	


