package pessoa;

public class Cliente extends Pessoa {
    private String plano;

    public Cliente(String nome, String cpf, String fone, int idade, char sexo, String plano) {
        super(nome, cpf, fone, idade, sexo);
        setPlano(plano);
    }

    public String getPlano() {
        return plano;
    }

    public void setPlano(String plano) {
        if (!plano.equalsIgnoreCase("anual") && !plano.equalsIgnoreCase("mensal")) {
            throw new IllegalArgumentException("Tipo de plano inválido. Deve ser 'Anual' ou 'Mensal'.");
        }
        this.plano = plano;
    }
}
