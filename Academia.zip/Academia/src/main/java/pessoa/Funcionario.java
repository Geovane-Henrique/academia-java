package pessoa;

public class Funcionario extends Pessoa {
    private String cargo;

    public Funcionario(String nome, String cpf, String fone, int idade, char sexo, String cargo) {
        super(nome, cpf, fone, idade, sexo);
        setCargo(cargo);
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        if (!cargo.equalsIgnoreCase("Instrutor") && !cargo.equalsIgnoreCase("Recepcionista")) {
            throw new IllegalArgumentException("Tipo de cargo inválido. Deve ser 'Instrutor' ou 'Recepcionista'.");
        }
        this.cargo = cargo;
    }

}
