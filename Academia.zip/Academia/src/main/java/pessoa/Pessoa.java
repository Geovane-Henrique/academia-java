package pessoa;

public abstract class Pessoa {
    private String nome;
    private String cpf;
    private String fone;
    private int idade;
    private char sexo;

    public Pessoa(String nome, String cpf, String fone, int idade, char sexo) {
        setNome(nome);
        setCpf(cpf);
        setFone(fone);
        setIdade(idade);
        setSexo(sexo);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome.length() < 3 || nome.length() > 30) {
            throw new IllegalArgumentException("Nome inválido. Deve ter entre 3 e 30 caracteres.");
        }
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if (cpf.length() != 11) {
            throw new IllegalArgumentException("CPF inválido. Deve conter 11 dígitos.");
        }
        this.cpf = cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        if (idade < 14 || idade >= 100) {
            throw new IllegalArgumentException("Idade inválida. Deve ser maior que 13 e menor que 100.");
        }
        this.idade = idade;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        if (Character.toUpperCase(sexo) != 'M' && Character.toUpperCase(sexo) != 'F') {
            throw new IllegalArgumentException("Sexo inválido. Deve ser 'M' ou 'F'.");
        }
        this.sexo = Character.toUpperCase(sexo);
    }

    public String getFone() { return fone; }

    public void setFone(String fone) {
        if (fone.length() != 8) {
            throw new IllegalArgumentException("Número de telefone inválido. Deve ter 8 dígitos.");
        }
        this.fone = fone;
    }
}

