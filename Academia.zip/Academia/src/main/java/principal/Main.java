package principal;

import java.sql.Connection;
import java.util.Scanner;

import conexao.Conexao;
import login.Login;
import menu.Menu;


public class Main {
	public static void main(String[] args) throws Exception {
		Scanner input = new Scanner(System.in);
		Menu menu = new Menu();
		 Login senha = new Login();

		 int op;
		 String resposta;
		
		 do {
			 
			 
	            menu.Menulogin();
	            op = input.nextInt();
	            switch (op){
	                case 1: 
	                	senha.clientesenha();
	                    break;
	                case 2:
						senha.funcionariosenha();
	                    break;
					case 3:
						System.out.println("\nSaindo do programa...");
						System.exit(0);
	                default: 
	                	System.out.println("Opção inválida! ");
	                break;
	            }
	            System.out.println("\nDeseja continuar(Sim/Nao)? ");
	            resposta = input.next();
		
	} while(resposta.equalsIgnoreCase("Sim"));
		  
	}
}


	            
	            
		 
		 
	

