package produto;

 abstract public class Armazem {
	
	private  double valor;
	private  String nome;
	private  int qtd;
	
	public Armazem(){
		
	}
	
	public Armazem(String nome, double valor, int qtd) {
		this.setnome(nome);
		this.setvalor(valor);
		this.setQtd(qtd);
		
	}
	
	public void setnome(String nome){
		this.nome = nome;
	}

	public String getnome() {
		return nome;
	
	}
	public void setvalor(double valor){
		this.valor = valor;
	}

	public double getvalor(){
		return valor;
	}
	
	
	public void leitura(){
		System.out.println("Nome: " + getnome());
		System.out.println("Valor: " + getvalor());
		System.out.println("Quantidade: " + getQtd());
			
	}
	
	public int getQtd() {
		return qtd;
	}


	public void setQtd(int qtd) {
		this.qtd = qtd;
	}


	


	
	
	
}
