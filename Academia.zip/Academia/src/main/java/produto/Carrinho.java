package produto;

import java.util.ArrayList;
import java.util.Scanner;

public class Carrinho {
	ArrayList<Carrinho> carrinho = new ArrayList<>();
	Scanner input = new Scanner(System.in);	
	public void adicionarcarrinho(){
		
		System.out.println("Digite o ID do produto: ");
		int in = input.nextInt();
		
		
		
		
	}
	
	

}
