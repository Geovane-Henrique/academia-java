package produto;

import java.util.ArrayList;
import java.util.Scanner;
import controler.Cadastros;
import opcao.Variaveis;

public class Produtonp extends Armazem {
	static Scanner input = new Scanner(System.in);	
     private int id;
	private String desc;
	static Variaveis variaveis;
	
	public Produtonp(String nome, double valor, int qtd, String desc,int id ) {
		super (nome,valor,qtd);
		this.id = id;
		this.desc = desc;
	}
	
public Produtonp() {
		
	}
	
	public int getId() {
		return id;
	}
	private static int nid =1;
	public void setid(int id){
		
		this.id = nid;
		nid++;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String toString(){
		return "\nID: "+this.getId()+"\nNome: "+ this.getnome()+"\nValor: "+ this.getvalor() +"\nDescrição: " + this.getDesc() +"\nQuantidade: " +this.getQtd();
		
	}
	
	
}
