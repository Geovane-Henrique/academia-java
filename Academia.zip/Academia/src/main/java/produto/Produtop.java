package produto;

import java.util.ArrayList;
import java.util.Scanner;

import controler.Cadastros;
import opcao.Variaveis;

public class Produtop extends Armazem {
	static Scanner input = new Scanner(System.in);	
	private double peso;
	private int id;
	static Variaveis variaveis;
	
	public Produtop(String nome, double valor, int qtd, double peso, int id){
		super (nome,valor,qtd);
		this.setid(id);
		
		this.peso = peso;
	}
	
	public Produtop() {
		
	}
	
	public int getId() {
		return id;
	}
	private static int nid =1;
	public void setid(int id){
		this.id = nid;
		nid++;
	}
	


public double getPeso() {
	return peso;
}

public void setPeso(double peso) {
	this.peso = peso;
}

public String toString(){
	return "\nID: " +this.getId()+ "\nNome:" + this.getnome()+ "\nValor:" + this.getvalor() + "\nQuantidade: " + this.getQtd();
	
}





}
