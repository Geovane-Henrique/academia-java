package repositroioBD;

import java.sql.Connection;
import java.sql.PreparedStatement;

import conexao.Conexao;

import pessoa.Cliente;

public class CadastroCliente {
	 public static void inserir(Cliente cliente) throws Exception {
	        Connection conn = null;
	        PreparedStatement ps = null;
	        String sql = "INSERT INTO cliente(CPF	, Nome, Telefone, Idade, Sexo,Plano) VALUES (?,?,?,?,?,?)";

	        conn = Conexao.getConexao();
	        ps = conn.prepareStatement(sql);
	        ps.setString(1, cliente.getCpf());
	        ps.setString(2, cliente.getNome());
	        ps.setString(3, cliente.getFone());
	        ps.setInt(4, cliente.getIdade());
	        ps.setString(5, String.valueOf(cliente.getSexo()));
	        ps.setString(6, cliente.getPlano());
	        
	        ps.executeUpdate();	      
	        conn.close();
	    }
}
