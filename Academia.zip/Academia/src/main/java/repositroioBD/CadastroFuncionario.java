package repositroioBD;

import java.sql.Connection;
import java.sql.PreparedStatement;

import conexao.Conexao;
import pessoa.Funcionario;

public class CadastroFuncionario {
	public static void inserir(Funcionario funcionario) throws Exception {
        Connection conn = null;
        PreparedStatement ps = null;
        String sql = "INSERT INTO `funcionario` (`CPF`, `Nome`, `Telefone`, `Idade`, `Sexo`, `cargo`) VALUES (?,?,?,?,?,?)";

        conn = Conexao.getConexao();
        ps = conn.prepareStatement(sql);
        ps.setString(1, funcionario.getCpf());
        ps.setString(2, funcionario.getNome());
        ps.setString(3, funcionario.getFone());
        ps.setInt(4, funcionario.getIdade());
        ps.setString(5, String.valueOf(funcionario.getSexo()));
        ps.setString(6, funcionario.getCargo());
        
        ps.executeUpdate();	      
        conn.close();
    }
}
