package repositroioBD;

import java.sql.Connection;
import java.sql.PreparedStatement;

import conexao.Conexao;
import produto.Produtonp;

public class CadastroProdutonp {
	public static void inserir(Produtonp produtonp) throws Exception {
        Connection conn = null;
        PreparedStatement ps = null;
        String sql = "INSERT INTO produtonp(Nome , quantidade, valor, descrição) VALUES (?,?,?,?)";

        conn = Conexao.getConexao();
        ps = conn.prepareStatement(sql);
        ps.setString(1, produtonp.getnome());
        ps.setInt(2, produtonp.getQtd());
        ps.setDouble(3, produtonp.getvalor());
        ps.setString(4, produtonp.getDesc());
        
        
        
        ps.executeUpdate();	      
        conn.close();
    }
}
