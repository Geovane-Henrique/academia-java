package repositroioBD;

import java.sql.Connection;
import java.sql.PreparedStatement;

import conexao.Conexao;
import produto.Produtop;

public class CadastroProdutop {
	public static void inserir(Produtop produtop) throws Exception {
        Connection conn = null;
        PreparedStatement ps = null;
        String sql = "INSERT INTO produtop(Nome , quantidade, valor, peso) VALUES (?,?,?,?)";

        conn = Conexao.getConexao();
        ps = conn.prepareStatement(sql);
        ps.setString(1, produtop.getnome());
        ps.setInt(2, produtop.getQtd());
        ps.setDouble(3, produtop.getvalor());
        ps.setDouble(4, produtop.getPeso());
        
        
        
        ps.executeUpdate();	      
        conn.close();
    }
}
